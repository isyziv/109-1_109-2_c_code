struct stackNode {
	char string[15];
	struct stackNode* next;
}LINK_;
typedef struct stackNode *link;