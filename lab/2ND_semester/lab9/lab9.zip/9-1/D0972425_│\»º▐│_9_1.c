#define _CRT_SECURE_NO_WARNINGS
//#include"link_setup.h"
#include"link_list.h"
#include<stdio.h>
#include<stdlib.h>
static link node;


void b_part(link* node, int a)
{

	node = free_head(node);
}
void c_part(link* node, int a)
{

	node = free_head(node);
}


}
int main()
{
	FILE* data;
	node = generate_link();
	node->data = 0;
	node->next = NULL;
	data = fopen("stack.txt", "r");
	f_r(data, node);
	int tmp[3];
	for (int i = 0; i != 3; i++)
	{
		tmp[i] = node->data;
		b_part(&node, 0);
	}
	for (int i = 0; i != 3; i++)
	{
		a_part(&node, tmp[i]);
	}
	puts(" ");
	int stack[100];
	int j = 0;
	for (; node->next!=NULL; j++)
	{
		stack[j] = node->data;
		b_part(&node, 0);
	}
	j--;
	for (;j>=0; j--)
	{
		printf("%d\t", stack[j]);
	}
	system("pause");
	return 0;
}
// !feof(data)