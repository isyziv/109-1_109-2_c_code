#include "link_setup.h"
link generate_link();
link insert(link* top);
link append(link *last);
link free_head(link* top);
link find_last(link top);
