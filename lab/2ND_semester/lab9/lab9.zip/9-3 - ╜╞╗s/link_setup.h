#include "tree.h"
struct stackNode {
	tree data;
	struct stackNode* next;
}LINK_;
typedef struct stackNode* link;